
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  user_count INT;
  assigned_role public.app_role;
  meta_role TEXT;
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email));

  meta_role := NEW.raw_user_meta_data->>'role';

  IF meta_role IN ('admin', 'general_user', 'trade_manager', 'transport_hub', 'driver', 'worker') THEN
    assigned_role := meta_role::public.app_role;
  ELSE
    SELECT COUNT(*) INTO user_count FROM auth.users;
    IF user_count <= 1 THEN
      assigned_role := 'admin';
    ELSE
      assigned_role := 'general_user';
    END IF;
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, assigned_role)
  ON CONFLICT (user_id, role) DO NOTHING;
  RETURN NEW;
END;
$function$;
